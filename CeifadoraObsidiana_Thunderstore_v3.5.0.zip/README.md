# Ceifadora Obsidiana — Scythes for Valheim

Four two-handed scythes, one for each stage of the game. Each has its own model, icon and stats.

| Scythe | Crafting | Damage | Effect |
|---|---|---|---|
| Iron Reaper (Ceifadora de Ferro) | Forge lvl 3 — Ancient Bark, Iron, Troll Hide | 70 slash | — |
| Black Metal Reaper (Ceifadora de Metal Negro) | Forge lvl 4 — same as the Black Metal Battleaxe | 105 slash | — |
| Obsidian Reaper (Ceifadora Obsidiana) | Black Forge lvl 2 — Black Metal, Eitr, Yggdrasil Wood, Obsidian, Blood Clots | 120 slash | Bleeding |
| Flametal Reaper (Ceifadora de Flametal) | Black Forge lvl 3 — Flametal, Ashwood, Charred Bone, Asksvin Hide | 135 slash + 40 poison | Poison |

## Combat
- **4-hit combo:** two battleaxe swings, then two spinning slashes that hit everyone around you (3rd hit ×1.3, 4th hit ×2 damage).
- **Special:** atgeir-style twirl with the scythe held away from the body.
- One hit per enemy per swing, so a spin can't hit the same enemy several times.
- Stamina matches the vanilla battleaxe (normal attacks) and atgeir (special) of the same tier.
- Battleaxe hit and block sounds, screen shake on hit and parry, and the battleaxe weapon trail.

## Requirements
- BepInExPack Valheim
- Jötunn
- **Every player on the server needs the mod.**

## Configuration
`BepInEx/config/fabiano.ceifadoraobsidiana.cfg` (created on first launch).
Damage and stamina per scythe (`[Balanco]`), sound timing (`[Sons]`), trail (`[Visual]`), and how the scythe sits in the hands (`[Encaixe]`).
Many settings apply while the game is running: just save the file.

---

## Português
Quatro foices de duas mãos, uma para cada fase do jogo: Ferro, Metal Negro, Obsidiana (sangramento) e Flametal (veneno).
Combo de 4 golpes (os dois últimos giram e acertam todos em volta), especial giratório, sons e efeitos do machado de guerra.
Todos os jogadores do servidor precisam ter o mod. Ajustes em `BepInEx/config/fabiano.ceifadoraobsidiana.cfg`.
