## 3.5.0
- First public release: Iron, Black Metal, Obsidian and Flametal scythes.
