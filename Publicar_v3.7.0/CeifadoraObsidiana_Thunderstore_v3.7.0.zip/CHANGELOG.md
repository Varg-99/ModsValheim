## 3.7.0
- Styles, like shields: each scythe can use the look of the earlier ones (choose at the workbench). Iron: own only; Black Metal: + Iron; Obsidian: + Iron and Black Metal; Flametal: all four. Works in hand, on the back, on the ground and on item stands, also in multiplayer.
- New low-poly Iron scythe model.
- Option `[Visual] Estilos` to turn styles off.

## 3.6.0
- Optional pixel textures in the vanilla Valheim style (`[Visual] TexturaPixel`).
- Fixed see-through spots on the blade, cape shaking while the scythe is equipped, and item stand orientation.

## 3.5.0
- First public release: Iron, Black Metal, Obsidian and Flametal scythes.
